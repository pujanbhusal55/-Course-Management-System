package com.pujan;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
// implementing ActionListener
public class Main implements ActionListener{
    // creating object of Jbutton and Jframe
    private JButton teh, std, admin,exit;
    private JFrame frame;

    // calling contructor
    void startGUI() {
        // setting tittle
        frame = new JFrame("Course management system");

        frame.setBackground(Color.gray); // setting background color

        std = new JButton();
        // setting button size
        std.setBounds(150,130,180,50);
        std.addActionListener(this); // perform task after clicking button
        std.setText("Students");
        std.setFocusable(false);

        frame.add(std);

        teh= new JButton();
        // setting button size
        teh.setBounds(150,210,180,50);
        teh.setText("Teachers");
        // perform task after clicking button
        teh.addActionListener(this);
        teh.setFocusable(false);

        frame.add(teh);
        // setting logo and it's size
        JLabel picc = new JLabel();
        ImageIcon picttu = new ImageIcon("seventh.png"); //setting logo name
        Image pis = picttu.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);// size of logo
        ImageIcon pit = new ImageIcon(pis);
        picc.setIcon(pit);
        picc.setBounds(30, 30, 60, 60);
        frame.add(picc);


        // setting a button and design Administrator button
        admin = new JButton();
        admin.setBounds(150,60,180,50);
        admin.setText("Administrator");
        admin.addActionListener(this); // perform task after clicking button
        admin.setFocusable(false);

        frame.add(admin);
        // setting a button and design Administrator button
        exit = new JButton();
        exit.setBounds(550, 350, 70, 40);
        exit.setText("Exit");
        exit.addActionListener(this); // perform task after clicking button
        exit.setFocusable(false);

        frame.add(exit);
        frame.setSize(700,500);
        frame.setLayout(null);

        frame.setLocationRelativeTo(null);
        frame.setResizable(false); // location donot resized

        // setting the background image
        JLabel aa = new JLabel();
        ImageIcon bg = new ImageIcon("1.manage.jpg"); // image name
        Image pia = bg.getImage().getScaledInstance(700, 500, Image.SCALE_SMOOTH); // image total size area
        ImageIcon pi = new ImageIcon(pia);
        aa.setIcon(pi);
        aa.setBounds(0, 0, 700, 500);
        frame.add(aa);
        frame.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) { // when button is click perform task

        if(e.getSource() == std) {

            frame.dispose(); // closing the previous open frame
            LogSignin log = new LogSignin("Student");
            log.userInputs();


        }

        if(e.getSource() == teh) {

            frame.dispose(); // closing the previous open frame
            LogSignin log = new LogSignin("Teacher");
            log.userInputs();

        }

        if(e.getSource() == admin) {

            frame.dispose(); // closing the previous open frame
            LogSignin log = new LogSignin("Admin");
            log.userInputs();

        }

        if(e.getSource() == exit){
            frame.dispose(); // closing the previous open frame
        }

    }

// main function
    public static void main(String[] args) {

        Main main = new Main();
        main.startGUI();

    }

}


